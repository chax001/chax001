package com.ritesh.accountservice.specification;

public class AccountSpecification {

}
