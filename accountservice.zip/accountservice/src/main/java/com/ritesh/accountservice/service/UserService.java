package com.ritesh.accountservice.service;

import java.util.List;

import com.ritesh.accountservice.model.Account;

public interface UserService {

	public List<Account> getAllAccount();

}
