package com.ritesh.accountservice.specification;

public class StatementSpecification {

}
