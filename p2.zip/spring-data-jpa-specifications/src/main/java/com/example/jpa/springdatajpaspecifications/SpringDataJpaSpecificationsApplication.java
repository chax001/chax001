package com.example.jpa.springdatajpaspecifications;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaSpecificationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaSpecificationsApplication.class, args);
	}

}
