package concurrent;

public class FibTest {

	public static int getFact(int n) {
		if (n <= 1) {
			return n;
		}
		return n * getFact(n - 1);
	}

	public static int getFib(int n) {
		if (n <= 1)
			return n;
		return getFib(n - 1) + getFib(n - 2);
	}

	public static void main(String[] args) {
//get fact
		System.out.println(getFact(10));

		for (int i = 1; i <= 10; i++) {
			System.out.print(getFib(i) + " ");
		}
	}

}
