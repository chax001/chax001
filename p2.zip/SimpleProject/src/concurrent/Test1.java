package concurrent;

public class Test1 {

	public static char[] revString(char[] carr, int start, int end) {

		if (start == end || start > end)
			return carr;
		char c1 = carr[start];
		carr[start] = carr[end];
		carr[end] = c1;
		return revString(carr, start + 1, end - 1);

	}

	public static String reverseString(String str) {

		// rit esh len=6
		// hsetir
		// 012 345

		char[] carr = str.toCharArray();
		int len = str.length();

		for (int i = 0; i < len / 2; i++) {
			char c1 = carr[i];
			carr[i] = carr[len - 1 - i];
			carr[len - 1 - i] = c1;
		}

		return new String(carr);
	}

	public static int getCount(int[] arr, int num) {
		int count = 0;

		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == num) {
				count++;
			}
		}

		return count;
	}

	public static int fact(int n) {
		if (n == 1) {
			return 1;
		}
		return n * fact(n - 1);
	}

	public static void main(String[] args) {

//		int[] arr = { 1, 3, 4, 5, 6, 7, 8, 3 };
//
//		System.out.println(getCount(arr, 3));

		System.out.println(reverseString("ritesh"));
		System.out.println(revString("ritesh".toCharArray(), 0, 5));

	}

}
