package concurrent;

public class Solution {
	private static String r1 = "ritesh";

	private static String r2 = "rahul";

	public static void main(String[] args) {
		Thread t1 = new Thread(() -> {
			synchronized (r1) {
				try {
					System.out.println("Thread t1 acquired lock on r1");
					Thread.sleep(500);
				} catch (InterruptedException e) {

					e.printStackTrace();
				}
				synchronized (r2) {
					System.out.println("Thread t1 acquired lock on r2");

				}

			}
		});
		Thread t2 = new Thread(() -> {
			synchronized (r2) {
				try {
					System.out.println("Thread t2 acquired lock on r2");
					Thread.sleep(500);
				} catch (InterruptedException e) {

					e.printStackTrace();
				}
				synchronized (r1) {
					System.out.println("Thread t2 acquired lock on r1");

				}

			}
		});

		t1.start();
		t2.start();

	}

}
