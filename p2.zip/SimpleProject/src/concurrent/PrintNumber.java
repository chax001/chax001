package concurrent;

public class PrintNumber {
	// private static AtomicInteger m = new AtomicInteger(0);
	volatile int m = 1;

	public void run(int k) throws InterruptedException {
		Thread t1 = new Thread(() -> {
			synchronized (this) {
				while (m < k) {

					try {
						if (m % 2 == 1)
							this.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					System.out.println("T1 prints" + m);
					m++;
					this.notify();
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {

						e.printStackTrace();
					}
				}
			}
		});
		Thread t2 = new Thread(() -> {
			synchronized (this) {
				while (m < k) {

					try {
						if (m % 2 == 0) {
							// System.out.println("T2 going to wait" + m);
							this.wait();
						}

					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					System.out.println("T2 prints" + m);

					m++;
					this.notify();
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}

				}
			}
		});
		t1.start();
		t2.start();

	}

	public static void main(String[] args) throws InterruptedException {
		new PrintNumber().run(10);
	}
}