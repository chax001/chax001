module SimpleProject {
}