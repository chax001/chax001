package solution;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Sol3 {

	public static int getWordCount(String str) {
		// my name is ritesh
		int count = 0;
		for (int i = 0; i < str.length(); i++) {
			if (((i > 0) && (str.charAt(i) != ' ') && (str.charAt(i - 1) == ' '))
					|| ((str.charAt(i) != ' ') && (i == 0))) {
				count++;
			}

		}

		return count;
	}

	public static int getWord(String str) {

		Pattern p = Pattern.compile("\\W");

		Matcher m = p.matcher(str);
		while (m.find()) {
			System.out.println(m.start());
		}
		return m.groupCount();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// my name is ritesh
		String str = " my name is ritesh ";
		System.out.println(getWordCount(str));
		// System.out.println(getWord(str));
	}

}
