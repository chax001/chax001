package solution;

import java.util.Arrays;

public class Sol2 {

	public static void main(String[] args) {
		// Array =10,15,8,49,25,98,97

		int[] arr = { 10, 15, 8, 49, 25, 98, 97 };

		Arrays.stream(arr).filter(n -> n % 2 == 0).forEach(System.out::print);

	}

}
