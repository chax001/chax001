package solution;

import java.util.Stack;

public class Sol1 {

	public static String printDecodedString(String str) {
		// s=21{AD3{D}}->2{ADDD}-->ADDDADDD

		// digit 48 to 57
		// char=65 to 90 97 to 122
		Stack<String> charStack = new Stack<>();
		Stack<Integer> countStack = new Stack<>();

		String result = "";
		int count = 0;
		String s = "";

		for (int i = 0; i < str.length(); i++) {
			int n = str.charAt(i);
			if (n >= 48 && n <= 57) {
				if ((i - 1 >= 0) && ((str.charAt(i - 1) >= 65 && str.charAt(i - 1) <= 90)
						|| (str.charAt(i - 1) >= 97 && str.charAt(i - 1) <= 122))) {
					charStack.add(s);
					s = "";
				}
				count = count * 10 + str.charAt(i) - '0';
			} else if ((n >= 65 && n <= 90) || (n >= 97 && n <= 122)) {

				s = s + str.charAt(i);

			} else if (str.charAt(i) == '{') {
				countStack.add(count);
				count = 0;

			} else if (str.charAt(i) == '}') {
				if (s != "") {
					charStack.add(s);
					s = "";
				}
				int k = countStack.pop();
				String l = charStack.pop();

				for (int j = 0; j < k; j++) {
					result = l + result;
				}

			}

		}

		return result;

	}

	public static void main(String[] args) {

		String s = "2{A}";

		System.out.println(printDecodedString(s));

	}

}
