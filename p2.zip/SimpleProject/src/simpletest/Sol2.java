package simpletest;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Sol2 implements name {

	public static void main(String[] args) {
		final List<Integer> list = new ArrayList<>();
		list.add(2);
		list.add(3);
		list.iterator();

		Comparator<Integer> c = (o1, o2) -> o1.compareTo(o2);

		List<Integer> list2 = new ArrayList<>();
		System.out.println(list);
		new Sol2().print();

		name.print2();
	}

	@Override
	public void display() {

	}

	@Override
	public void print() {
		System.out.println("default method");
	}
}

@FunctionalInterface
interface name {

	public static final String a = "";

	void display();

	default void print() {
		System.out.println("default method");
	}

	static void print2() {
		System.out.println("static method");
	}
}