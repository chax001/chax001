package simpletest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Sol1 {

	public static void main(String[] args) {

		List<Integer> al = new ArrayList<>();
		al.add(1);
		al.add(22);
		al.add(3);
		al.add(4);
		al.add(5);
		al = al.stream().filter(n -> n > 3).sorted().collect(Collectors.toList());
		System.out.println(al);
		Iterator<Integer> itr = al.iterator();
		while (itr.hasNext()) {
			if (itr.next() == 2) {
				// will not throw Exception
				itr.remove();

			}

		}

		System.out.println(al);
		List<Integer> list = new ArrayList<>();
		// Queue<Integer> list = new LinkedList<>();
		// List<Integer> list = new LinkedList<>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);

		for (Integer integer : list) {
			if (integer == 2) {
				// list.add(6);
			}
			if (integer == 4) {
				list.remove(0);
			}

		}
		System.out.println(list);
		Map<Integer, String> m = new HashMap<>();
		m.put(1, "ss");
		m.put(2, "sad");

	}

}
