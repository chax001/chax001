package abstracttest;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

public class Test7 {

	public static boolean checkBalanceOrNot(String s) {

		Stack<Character> st = new Stack<Character>();
		Map<Character, Character> m = new HashMap<>();

		m.put('}', '{');
		m.put(']', '[');
		m.put(')', '(');

		for (int i = 0; i < s.length(); i++) {
			if (!m.containsKey(s.charAt(i))) {
				st.add(s.charAt(i));
			} else {
				if (!(st.pop() == m.get(s.charAt(i)))) {
					return false;
				}
			}

		}
		if (st.empty())
			return true;
		return false;
	}

	public static void main(String[] args) {
		String str = "{}[[](){}";
		System.out.println(checkBalanceOrNot(str));

	}

}
