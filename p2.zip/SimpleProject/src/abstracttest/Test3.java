package abstracttest;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Fruit {
	private String name;
	private boolean imported;

	public Fruit(String name, boolean imported) {
		super();
		this.name = name;
		this.imported = imported;
	}

	public Fruit() {

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isImported() {
		return imported;
	}

	public void setImported(boolean imported) {
		this.imported = imported;
	}

	@Override
	public String toString() {

		return "Name :" + this.name;
	}

}

public class Test3 {

	public static String getString(String s) {

		while (true) {
			if (s.indexOf("www") != -1) {
				int m = s.indexOf("www");
				s = s.substring(0, m) + s.substring(m + 1);
				System.out.println("sendy moves " + s);
			} else {
				return "bob";
			}
			if (s.indexOf("bbb") != -1) {
				int m = s.indexOf("bbb");
				s = s.substring(0, m) + s.substring(m + 1);
				System.out.println("Bob moves " + s);
			} else {
				return "sendy";
			}
		}
	}

	public static void main(String[] args) {
		String s = "wwwbbbbwww";
		System.out.println(getString(s));
		List<Fruit> list = new ArrayList<>();
		list.add(new Fruit("mango", true));
		list.add(new Fruit("papaya", false));
		List<Fruit> fl = list.stream().filter(n -> n.isImported()).collect(Collectors.toList());

		System.out.println(fl);
	}

}
