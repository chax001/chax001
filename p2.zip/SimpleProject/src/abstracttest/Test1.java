package abstracttest;

public abstract class Test1 {
	String color;

	public void display() {
		System.out.println(this.color);

	}

	public Test1() {

	}

	public Test1(String color) {
		this.color = color;
	}

}
