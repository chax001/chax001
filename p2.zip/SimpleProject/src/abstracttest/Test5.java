package abstracttest;

import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test5 {

	public static void main(String[] args) {
		String input = "er$8y2*2hh81";

		Pattern p = Pattern.compile("\\d");

		Matcher m = p.matcher(input);
		Set<Character> s = new TreeSet<>();
		while (m.find()) {
			if ((input.charAt(m.start()) - '0') % 2 == 0)
				s.add(input.charAt(m.start()));

		}
		System.out.println(s);
	}

}
