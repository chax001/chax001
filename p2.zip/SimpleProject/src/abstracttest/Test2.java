package abstracttest;

public class Test2 {
	static {
		initialize();
	}
	public static int sum;
	static {
		System.out.println(sum);
	}

	public static void main(String[] args) {
	}

	private static void initialize() {
		sum = 10;
	}

}
