package abstracttest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Test6 {

	public static List<Integer> getIndexs(List<Integer> list, int target) {
		Map<Integer, Integer> m = new HashMap<>();
		List<Integer> result = new ArrayList<>();
		for (int i = 0; i < list.size(); i++) {
			if (m.containsKey(list.get(i))) {
				result.add(i);
				result.add(m.get(list.get(i)));
			} else {
				m.put(target - list.get(i), i);
			}
		}
		return result;
	}

	public static void main(String[] args) {

		String s = "red";

		switch (s) {
		case "red": {

			System.out.println("red");
		}
		case "green": {

			System.out.println("red");
		}

		}
		// input=[2,8,12,45,34] target=14 0,2
		List<Integer> st = new ArrayList<Integer>();
		st.add(2);
		st.add(8);
		st.add(12);
		st.add(45);
		st.add(34);

		System.out.println(getIndexs(st, 10));

	}

	public int get() {
		return 0;
	}

	public void get(int b) {

	}

	public int get(long b) {
		return 0;
	}

//	public int division(int a, int b) {
//		int result = a / b;
//		return result;
//	}
//
//	public double division(float a, float b) {
//		double result = a / b;
//		return result;
//	}

	public int division(int a, int b) {
		int result = a / b;
		return result;
	}

	public double division(float a, int b) {
		double result = a / b;
		return result;
	}
}
