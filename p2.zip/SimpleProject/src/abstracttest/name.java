package abstracttest;

public interface name {
	public static final String a = "";

	void display();

	default void print() {
		System.out.println("default method");
	}

}
