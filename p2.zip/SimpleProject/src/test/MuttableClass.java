package test;

public final class MuttableClass {
	final String name;

	public MuttableClass(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

}
