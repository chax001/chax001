package test;

import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

public class TreeMapTest {
	// sorting by value
	static Map<Integer, String> valurSort(Map<Integer, String> map) {

		Comparator<Integer> comp = (Integer m1, Integer m2) -> map.get(m1).compareTo(map.get(m2));

		Map<Integer, String> m = new TreeMap<Integer, String>(comp);
		m.putAll(map);
		return m;

	}

	public static void main(String[] args) {
//sorting by keys
//		Map<Integer, String> m = new TreeMap<>((m1, m2) -> {
//			return m2.compareTo(m1);
//		});

		Map<Integer, String> m = new TreeMap<>();
		m.put(3, "Amit");
		m.put(1, "Balu");
		m.put(6, "Aan");
		m.put(8, "Raju");
		m.put(9, "Aa");
		m = valurSort(m);
		System.err.println(m);

	}

}
