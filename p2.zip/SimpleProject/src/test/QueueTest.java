package test;

import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class QueueTest {

	public static void main(String[] args) {
		List<Integer> list = new LinkedList<>();

		list.add(1);
		list.add(3);
		list.add(5);
		list.add(8);

		System.out.println(list);
		int n = list.size();
		for (int i = 0; i < n; i++) {
			System.out.println(list.remove(0));

		}
		System.out.println("------------List end----------");
		Queue<Integer> queue = new LinkedList<>();
		queue.add(3);
		queue.add(6);
		queue.add(8);
		queue.add(9);
		while (!queue.isEmpty()) {
			System.out.println(queue.poll());
		}

		System.out.println("-----------queue end----------");

		Deque<Integer> dq = new LinkedList<>();

		dq.add(3);
		dq.add(5);
		dq.add(9);

		System.out.println(dq);
		System.out.println(dq.getFirst());
		System.out.println(dq.getLast());
		dq.addFirst(99);
		dq.addLast(88);
		System.out.println(dq);
		System.out.println(dq.removeFirst());
		System.out.println(dq.removeLast());
		System.out.println(dq);

	}

}
