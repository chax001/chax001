package test;

import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Set;

public class PriorityQueueTest {

	public static void main(String[] args) {

		PriorityQueue<Integer> p = new PriorityQueue<Integer>();
		Set<String> s = new HashSet<>();

		String s1 = new String("Ritesh");
		String s2 = new String("Ritesh");
		System.out.println(s1.intern());
		// String s3 = "Ritesh";

//
//		s.add(s1);
//		s.add(s2);
//		s.add(s3);
//		System.out.println(s.size());
//		System.out.println(s1.hashCode() == s2.hashCode());
//		System.out.println(s1.hashCode() == s3.hashCode());

	}

}
